Credits
=======

### Software Design and Code
* Georg Essl

### Lua support Code
* Bryan Summersett
* Jongwook Kim
* Georg Essl

### Interface Design
* Georg Essl
* Alexander Mueller

### Camera API
 * Patrick O'Keefe

### Soar Integration, API and examples
 * Nate Derbinsky
 * Georg Essl

### Android Port
 * Jongwook Kim

### Sounds
* Devin Kerr
* Georg Essl

### Example faces
* Alexander Mueller
* Bryan Summersett
* Jongwook Kim
* Devin Kerr
* Eric Lapointe
* Justin Crowell
* Raphael Szymanski
* Rishi Daftuar
* Owen Campbell
* Colin Neville
* Colin Zyskowski
* Georg Essl

### Documentation
* Bryan Summersett
* Georg Essl

[urMus API Overview](overview.html)
