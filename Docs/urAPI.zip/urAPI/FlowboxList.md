Global Flowboxes
================
The following flowboxes are defined globally and can be used directly or as prototypes for cloning them. 

Sources
=======

Sources are flowboxes which do not have an input. They are typically driven by user input and provide relevant input data as output.

Accel
-------
### Description
Provides hardware specific 3-axis accelerometer data. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = 33.3Hz
### Outputs
- X (0): X-Axis acceleration (-1,1)
- Y (1): Y-Axis acceleration (-1,1)
- Z (2): Z-Axis acceleration (-1,1)

Camera
--------
### Description
Provides hardware specific camera-derived data. This flowbox is self-timed and provides a stable rate. It cannot be instanced. It is subject to other camera settings.
### Typical native rate
rate = 30.0Hz
### Outputs
- Bright (0): Overall Brightness (0,1)
- Red (1): Overall Red channel contribution (0,1)
- Green (2): Overall Green channel contribution (0,1)
- Blue (3): Overall Blue channel contribution (0,1)
- Edge (4): Overall Edge/gradient contribution (0,1)

Compass
---------
### Description
Provides hardware specific 3-axis magnetic field and compass data. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = not specificed
### Outputs
- X (0): X-Axis magnetic strength (-1,1)
- Y (1): Y-Axis magnetic strength (-1,1)
- Z (2): Z-Axis magnetic strength (-1,1)
- North (3): Compass geographic north (-1,1) -> (-180,180) degrees

Location
----------
### Description
Provides hardware specific GPS data. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = not specificed
### Outputs
- Lat (0): Geographical latitude (-1,1) -> (-180,180) degrees
- Long (1): Geographical longitude (-1,1) -> (-180,180) degrees

Mic
-----
### Description
Provides hardware microphone data. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = 48000Hz
### Output
- Out (0): Microphone data (-1,1)

Net
-----
### Description
Provides network data. This flowbox is self-timed but does not provide a stable rate. It must be instanced.
### Typical native rate
rate = variable, depending on incoming network data timing
### Output
- Out (0): Incoming Network data (-1,1)

Push
------
### Description
Provides data pushed by an urMus lua program. This flowbox is self-timed but does not provide a stable rate. It must be instanced. Calling its :Push(data) method will increase time and send data to its output.
### Typical native rate
rate = variable, depending on the pattern Push:Push() is called
### Output
- Out(0): Programmatic pushed data (-1,1)

RotRate
---------
### Description
Provides hardware specific 3-axis gyroscope data. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = 60Hz
### Outputs
- x (0): X-axis angular velocity (-1,1)
- y (1): Y-axis angular velocity (-1,1)
- z (2): Z-axis angular velocity (-1,1)

Touch
-------
### Description
Provides multi-touch contact coordinates for up to 11 contacts (less may be available for certain hardware). This flowbox is self-timed but does not provide a stable rate. It cannot be instanced.
### Typical native rate
rate = variable, depending on multi-touch event pattern
### Outputs
- x1 (0): x position of first multi-touch contact (-1,1)
- y1 (1): y position of first multi-touch contact (-1,1)
- x2 (2): x position of second multi-touch contact (-1,1)
- y2 (3): y position of second multi-touch contact (-1,1)
- x3 (4): x position of third multi-touch contact (-1,1)
- y3 (5): y position of third multi-touch contact (-1,1)
- x4 (6): x position of forth multi-touch contact (-1,1)
- y4 (7): y position of forth multi-touch contact (-1,1)
- x5 (8): x position of fifth multi-touch contact (-1,1)
- y5 (9): y position of fifth multi-touch contact (-1,1)
- x6 (10): x position of sixth multi-touch contact (-1,1)
- y6 (11): y position of sixth multi-touch contact (-1,1)
- x7 (12): x position of seventh multi-touch contact (-1,1)
- y7 (13): y position of seventh multi-touch contact (-1,1)
- x8 (14): x position of eighth multi-touch contact (-1,1)
- y8 (15): y position of eighth multi-touch contact (-1,1)
- x9 (16): x position of nineth multi-touch contact (-1,1)
- y9 (17): y position of nineht multi-touch contact (-1,1)
- x10 (18): x position of tenth multi-touch contact (-1,1)
- y10 (19): y position of tenth multi-touch contact (-1,1)
- x11 (20): x position of eleventh multi-touch contact (-1,1)
- y11 (21): y position of eleventh multi-touch contact (-1,1)

Manipulators
============

Manipulators are flowboxes which have both at least one input and one output. They are typically manipulate data or generate controllable data. Traditionally these are associated with unit generators or filters. A manipulator can have coupled input/output pairs. This means that a timed update at one side must require a timed update on the other side.

SinOsc
--------
### Description
Generates a sine wave. It is not self-timed and derives its time update from being pulled at the output WaveForm. It provides not couples.
### Source of Rate
Pulling output WaveForm (0)
### Couples
None
### Inputs
- Freq (0): Frequency (-1,0,1) -> log(.,55,24000)
- Amp (1): Amplitude (0,1)
- SRate (2): Rate (-1,0,1) -> (-4,0,4) with 0.25->1 being standard rate
- Time (3): Time(-1,1)
### Output
- WaveForm (0): (-1,1)

Avg
-----
### Description
Computes a sliding average of the incoming data. It is not self-timed and has coupled input/outputs.
### Source of Rate
Any change to input In (0) or output Out (0)
### Couples
In (0) <-> Out (0)
### Inputs
- In (0): (-1,1)
- Avg (1): (-1,1) -> (1,511), default = 256

Dist3
--------
### Description
Computes the distance of an input 3-vector against a stored 3-vector. While Train is 1 it will store the inputs in internal storage. If train is -1 it will compute the distance. It is not self-timed and has no couples.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In1 (0): (-1,1)
- In2 (1): (-1,1)
- In3 (2): (-1,1)
- Train (3): (-1,1)
### Output
- Out (0): (-1,1)

Min
-----
### Description
Provides the minimum of two inputs at the output. It is not self-timed and has no couples.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In1 (0): (-1,1)
- In2 (1): (-1,1)
### Output
- Out (0): (-1,1)

Max
-----
### Description
Provides the maximum of two inputs at the output. It is not self-timed and has no couples.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In1 (0): (-1,1)
- In2 (1): (-1,1)
### Output
- Out (0): (-1,1)

MinS
------
### Description
Indicates which is the minimum of two inputs at the output. Outputs -1 if In1 is smaller, and 1 if In2 is smaller. It is not self-timed and has no couples.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In1 (0): (-1,1)
- In2 (1): (-1,1)
### Output
- Out (0): -1 or 1
		
MaxS
------
### Description
Indicates which is the maximum of two inputs at the output. Outputs -1 if In1 is bigger, and 1 if In2 is bigger. It is not self-timed and has no couples.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In1 (0): (-1,1)
- In2 (1): (-1,1)
### Output
- Out (0): -1 or 1
		
Nope
------
#Description
Does nothing. It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
Inv
-----
#Description
Numerically inverts the input (a -> -a). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)

V
---
#Description
Computes a piece-wise linear transfer function with a V shape with (-1->1, 0->0, 1->1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (0,1)
	
FullV
-------
#Description
Computes a piece-wise linear transfer function with a V shape with (-1->1, 0->-1, 1->1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
DV
----
#Description
Computes a piece-wise linear transfer function with an inverted V shape with (-1->0, 0->1, 1->0). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (0,1)
	
FullDV
--------
#Description
Computes a piece-wise linear transfer function with an inverted V shape with (-1->-1, 0->1, 1->-1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
CJ
----
#Description
Computes a piece-wise linear transfer function with shifts the interval (-1,0,1) -> (0,1,-1), creating a center jump condition. This is equivalent to a phase shift of pi. It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
SQ
----
#Description
Computes a piece-wise linear transfer function with creates a square wave response. (-a,0,a) -> (-1,0,1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
PGate
-------
#Description
Computes a piece-wise linear transfer function which sets all negative input to zero (-a,0,a) -> (0,0,a). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)

NGate
-------
#Description
Computes a piece-wise linear transfer function which sets all positive input to zero (-a,0,a) -> (-a,0,0). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
Pos
-----
#Description
Computes a linear transfer function creating an all-positive output (-1,0,1) -> (0,0.5,1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
Neg
-----
#Description
Computes a linear transfer function creating an all-negative output (-1,0,1) -> (-1,-0.5,0). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
ZPuls
-------
#Description
Generates a unit pulse when the input is zero (0->1). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)

SLP
-----
#Description
Computes a simple two-point average which acts like a basic low-pass filter. It takes returns the average of the current and the previous sample.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)

PosSqr
--------
#Description
Computes a quadratic transfer function creating an all-positive output (-a,0,a) -> (a^2,0,a^2). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)
	
Oct
-----
#Description
Returns an octave range starting at base frequency Freq.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Inputs
- In (0): (-1,1)
- Freq (1): Frequency (-1,0,1) -> log(.,55,24000)
### Output
- Out (0): (-1,1)

Range
-------
#Description
Computes a linear transfer function creating a linear output (-1,1) -> (bottom,top). It is coupled for input In and output Out.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Inputs
- In (0): (-1,1)
- Bottom (1): (-1,1)
- Top (2): (-1,1)
### Output
- Out (0): (-1,1)
	
Quant
-------
#Description
Quantizes the smooth incoming signals to semi-tone intervals.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Input
- In (0): (-1,1)
### Output
- Out (0): (-1,1)

Gain
------
#Description
Applies a gain factor.
### Source of Rate
Any change at input In (0) or output Out (0)
### Couples
- In (0) <-> Out (0)
### Inputs
- In (0): (-1,1)
- Gain (1): (-1,1)
### Output
- Out (0): (-1,1)


Sample
--------
#Description
Allows to play back a select sample from a list of loaded sample files. This flowbox has an additional method called AddFile(filename) to add files to its sample pool.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- Amp (0): (-1,1)
- Rate (1): Rate (-1,0,1) -> (-4,0,4) with 0.25->1 being standard rate
- Pos (2): (-1,1)
- Sample (3): (-1,1)
- Loop (4): (-1,1)
### Output
- Out (0): (-1,1)
	
Looper
--------
#Description
Allows the recording and play back a sample. While the input to Record is 1, it will record into an internal buffer. This will be played back looped when Play is 1.
### Source of Rate
Pulling output Out (0)
### Couples
None
### Inputs
- In (0): (-1,1)
- Amp (1): (-1,1)
- Rate (2): Rate (-1,0,1) -> (-4,0,4) with 0.25->1 being standard rate
- Record (3): (-1,1)
- Play (4): (-1,1)
- Pos (5): (-1,1)
### Output
- Out (0): (-1,1)

CMap
------
### Description
Generates a circle map wave. A circle map is a non-linear oscillator. If the non-linearity is -1 it will behave like a linear sine oscillator. It is not self-timed and derives its time update from being pulled at the output WaveForm. It provides not couples.
### Source of Rate
Pulling output WaveForm (0)
### Couples
None
### Inputs
- Freq (0): Frequency (-1,0,1) -> log(.,55,24000)
- NonL (1): Generic (-1,1)
- Amp (2): Amplitude (0,1)
- SRate (3): Rate (-1,0,1) -> (-4,0,4) with 0.25->1 being standard rate
- Time (4): Time(-1,1)
### Output
- WaveForm (0): (-1,1)

Sinks
=====

Sinks are flowboxes which do not have an output. They are typically driving device actuation, output to the user, or outgoing network traffic derived from the data at its input.

Dac
-----
### Description
Provides hardware speaker playback. This flowbox is self-timed and provides a stable rate. It cannot be instanced.
### Typical native rate
rate = 48000Hz
### Input
- In (0): Audio data (-1,1)

Net
-----
### Description
Provides network data. This flowbox is self-timed but does not provide a stable rate. It must be instanced.
### Typical native rate
rate = variable, depending on incoming network data timing
### Input
- In (0): Outgoing Network data (-1,1)
	
Vis
-----
### Description
Provides pulling data at visual rates. This flowbox is self-timed but does not provide a stable rate, however the target rate is around 60Hz. It cannot be instanced. This flowbox offers a special method called Get() which allows access to the last data point acquired. Get is guaranteed to have been updated before the OnUpdate event fires.
### Typical native rate
rate = variable, depending on computational and graphics load, target is 60Hz
### Input
- In (0): Pulled visual data (-1,1)
	
STK Below

Plucked
---------

	ursObject* object;

	object = new ursObject("Plucked", Plucked_Constructor, Plucked_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Plucked_Tick, Plucked_Out, NULL);
	object->AddIn("In", "Generic", Plucked_In);
	object->AddIn("Freq", "Frequency", Plucked_SetFrequency);
	urmanipulatorobjectlist.Append(object);

ADSR
------
	
	object = new ursObject("ADSR", ADSR_Constructor, ADSR_Destructor,5,1);
	object->AddOut("WaveForm", "TimeSeries", ADSR_Tick, ADSR_Out, NULL);
	object->AddIn("In", "Generic", ADSR_In);
	object->AddIn("Attack", "Rate", ADSR_SetAttack);
	object->AddIn("Decay", "Rate", ADSR_SetDecay);
	object->AddIn("Sustain", "Threshold", ADSR_SetSustain);
	object->AddIn("Release", "Rate", ADSR_SetRelease);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Asymp
-------
	
	object = new ursObject("Asymp", Asymp_Constructor, Asymp_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Asymp_Tick, Asymp_Out, NULL);
	object->AddIn("In", "Generic", Asymp_In);
	object->AddIn("Tau", "Rate", Asymp_SetTau);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

BandedWG
----------
	
#ifdef INCLUDE_COMPHEAVY_STKS
	object = new ursObject("BandedWG", BandedWG_Constructor, BandedWG_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", BandedWG_Tick, BandedWG_Out, NULL);
	object->AddIn("Pluck", "Generic", BandedWG_Pluck);
	object->AddIn("Freq", "Frequency", BandedWG_SetFrequency);
	object->AddIn("Pos", "Position", BandedWG_SetPosition);
	urmanipulatorobjectlist.Append(object);
#endif

BiQuad
--------

	object = new ursObject("BiQuad", BiQuad_Constructor, BiQuad_Destructor,5,1);
	object->AddOut("WaveForm", "TimeSeries", BiQuad_Tick, BiQuad_Out, NULL);
	object->AddIn("In", "Generic", BiQuad_In);
	object->AddIn("Reson", "Freq", BiQuad_SetResonance);
	object->AddIn("Q", "Q", BiQuad_SetQ);
	object->AddIn("Notch", "Freq", BiQuad_SetNotch);
	object->AddIn("NQ", "Q", BiQuad_SetNQ);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Blit
------
	
	object = new ursObject("Blit", Blit_Constructor, Blit_Destructor,4,1);
	object->AddOut("WaveForm", "TimeSeries", Blit_Tick, Blit_Out, NULL);
	object->AddIn("In", "Generic", Blit_In);
	object->AddIn("Freq", "Frequency", Blit_SetFrequency);
	object->AddIn("Phase", "Phase", Blit_SetPhase);
	object->AddIn("Harms", "Harmonics", Blit_SetHarmonics);
	urmanipulatorobjectlist.Append(object);

BlitSaw
---------
	
	object = new ursObject("BlitSaw", BlitSaw_Constructor, BlitSaw_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", BlitSaw_Tick, BlitSaw_Out, NULL);
	object->AddIn("In", "Generic", BlitSaw_In);
	object->AddIn("Freq", "Frequency", BlitSaw_SetFrequency);
	object->AddIn("Harms", "Harmonics", BlitSaw_SetHarmonics);
	urmanipulatorobjectlist.Append(object);

BlitSq
--------

	object = new ursObject("BlitSq", BlitSquare_Constructor, BlitSquare_Destructor,4,1);
	object->AddOut("WaveForm", "TimeSeries", BlitSquare_Tick, BlitSquare_Out, NULL);
	object->AddIn("In", "Generic", BlitSquare_In);
	object->AddIn("Freq", "Frequency", BlitSquare_SetFrequency);
	object->AddIn("Phase", "Phase", BlitSquare_SetPhase);
	object->AddIn("Harms", "Harmonics", BlitSquare_SetHarmonics);
	urmanipulatorobjectlist.Append(object);

BlowBotl
----------
	
	object = new ursObject("BlowBotl", BlowBotl_Constructor, BlowBotl_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", BlowBotl_Tick, BlowBotl_Out, NULL);
	object->AddIn("In", "Generic", BlowBotl_In);
	object->AddIn("Freq", "Frequency", BlowBotl_SetFrequency);
	urmanipulatorobjectlist.Append(object);

BlowHol
---------
	
	object = new ursObject("BlowHol", BlowHole_Constructor, BlowHole_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", BlowHole_Tick, BlowHole_Out, NULL);
	object->AddIn("In", "Generic", BlowHole_In);
	object->AddIn("Freq", "Frequency", BlowHole_SetFrequency);
	urmanipulatorobjectlist.Append(object);

Bowed
-------

	object = new ursObject("Bowed", Bowed_Constructor, Bowed_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", Bowed_Tick, Bowed_Out, NULL);
	object->AddIn("In", "Generic", Bowed_In);
	object->AddIn("Freq", "Frequency", Bowed_SetFrequency);
	object->AddIn("Vibrato", "Generic", Bowed_SetVibrato);
	urmanipulatorobjectlist.Append(object);

BowTbl
--------
	
	object = new ursObject("BowTbl", BowTable_Constructor, BowTable_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", BowTable_Tick, BowTable_Out, NULL);
	object->AddIn("In", "Generic", BowTable_In);
	object->AddIn("Offset", "Generic", BowTable_SetOffset);
	object->AddIn("Slope", "Generic", BowTable_SetSlope);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Brass
-------

	object = new ursObject("Brass", Brass_Constructor, Brass_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Brass_Tick, Brass_Out, NULL);
	object->AddIn("In", "Generic", Brass_In);
	object->AddIn("Freq", "Frequency", Brass_SetFrequency);
	urmanipulatorobjectlist.Append(object);
	
#ifdef INCLUDE_COMPHEAVY_STKS
	object = new ursObject("Chorus", Chorus_Constructor, Chorus_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", Chorus_Tick, Chorus_Out, NULL);
	object->AddIn("In", "Generic", Chorus_In);
	object->AddIn("ModDepth", "Generic", Chorus_SetModDepth);
	object->AddIn("ModFreq", "Frequency", Chorus_SetModFrequency);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);
#endif

Clarinet
----------
	
	object = new ursObject("Clarinet", Clarinet_Constructor, Clarinet_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Clarinet_Tick, Clarinet_Out, NULL);
	object->AddIn("In", "Generic", Clarinet_In);
	object->AddIn("Freq", "Frequency", Clarinet_SetFrequency);
	urmanipulatorobjectlist.Append(object);

Delay
-------
	
	object = new ursObject("Delay", Delay_Constructor, Delay_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Delay_Tick, Delay_Out, NULL);
	object->AddIn("In", "Generic", Delay_In);
	object->AddIn("Delay", "Time", Delay_SetDelay);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);
	
DelayA
--------
	
	object = new ursObject("DelayA", DelayA_Constructor, DelayA_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", DelayA_Tick, DelayA_Out, NULL);
	object->AddIn("In", "Generic", DelayA_In);
	object->AddIn("Delay", "Time", DelayA_SetDelay);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

DelayL
--------
	
	object = new ursObject("DelayL", DelayL_Constructor, DelayL_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", DelayL_Tick, DelayL_Out, NULL);
	object->AddIn("In", "Generic", DelayL_In);
	object->AddIn("Delay", "Time", DelayL_SetDelay);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Echo
------

	object = new ursObject("Echo", Echo_Constructor, Echo_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", Echo_Tick, Echo_Out, NULL);
	object->AddIn("In", "Generic", Echo_In);
	object->AddIn("Echo", "Time", Echo_SetDelay);
	object->AddIn("Mix", "Mix", Echo_SetEffectMix);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Env
-----
	
	object = new ursObject("Env", Envelope_Constructor, Envelope_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Envelope_Tick, Envelope_Out, NULL);
	object->AddIn("In", "Generic", Envelope_In);
	object->AddIn("Time", "Time", Envelope_SetTime);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Flute
-------
	
	object = new ursObject("Flute", Flute_Constructor, Flute_Destructor,5,1);
	object->AddOut("WaveForm", "TimeSeries", Flute_Tick, Flute_Out, NULL);
	object->AddIn("In", "Generic", Flute_In);
	object->AddIn("Freq", "Frequency", Flute_SetFrequency);
	object->AddIn("JetRefl", "Generic", Flute_SetJetReflection);
	object->AddIn("EndRefl", "Generic", Flute_SetEndReflection);
	object->AddIn("JetDelay", "Time", Flute_SetJetDelay);
	urmanipulatorobjectlist.Append(object);
	
JCRev
-------

	object = new ursObject("JCRev", JCRev_Constructor, JCRev_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", JCRev_Tick, JCRev_Out, NULL);
	object->AddIn("In", "Generic", JCRev_In);
	object->AddIn("T60", "Time", JCRev_SetT60);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

JetTbl
--------

	object = new ursObject("JetTbl", JetTable_Constructor, JetTable_Destructor,1,1);
	object->AddOut("WaveForm", "TimeSeries", JetTable_Tick, JetTable_Out, NULL);
	object->AddIn("In", "Generic", JetTable_In);
	urmanipulatorobjectlist.Append(object);

Mod
-----

	object = new ursObject("Mod", Modulate_Constructor, Modulate_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", Modulate_Tick, Modulate_Out, NULL);
//	object->AddIn("In", "Generic", Modulate_In);
	object->AddIn("VibRate", "Rate", Modulate_SetVibratoRate);
	object->AddIn("VibGain", "Gain", Modulate_SetVibratoGain);
	object->AddIn("RandGain", "Gain", Modulate_SetRandomGain);
	urmanipulatorobjectlist.Append(object);

NRev
------
	
	object = new ursObject("NRev", NRev_Constructor, NRev_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", NRev_Tick, NRev_Out, NULL);
	object->AddIn("In", "Generic", NRev_In);
	object->AddIn("T60", "Time", NRev_SetT60);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

OnePole
---------
	
	object = new ursObject("OnePole", OnePole_Constructor, OnePole_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", OnePole_Tick, OnePole_Out, NULL);
	object->AddIn("In", "Generic", OnePole_In);
	object->AddIn("Reson", "Frequency", OnePole_SetResonance);
//	object->AddIn("Q", "Q", OnePole_SetQ);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

OneZero
---------
	
	object = new ursObject("OneZero", OneZero_Constructor, OneZero_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", OneZero_Tick, OneZero_Out, NULL);
	object->AddIn("In", "Generic", OneZero_In);
	object->AddIn("Notch", "Frequency", OneZero_SetNotch);
//	object->AddIn("B1", "Generic", OneZero_SetB1);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

PitShift
----------

	object = new ursObject("PitShift", PitShift_Constructor, PitShift_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", PitShift_Tick, PitShift_Out, NULL);
	object->AddIn("In", "Generic", PitShift_In);
	object->AddIn("Shift", "Generic", PitShift_SetShift);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

AllPass
---------
	
	object = new ursObject("AllPass", AllPass_Constructor, AllPass_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", AllPass_Tick, AllPass_Out, NULL);
	object->AddIn("In", "Generic", AllPass_In);
	object->AddIn("Coeff", "Generic", AllPass_SetAllpass);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

ZeroBlk
---------
	
	object = new ursObject("ZeroBlk", ZeroBlock_Constructor, ZeroBlock_Destructor,1,1);
	object->AddOut("WaveForm", "TimeSeries", ZeroBlock_Tick, ZeroBlock_Out, NULL);
	object->AddIn("In", "Generic", ZeroBlock_In);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

PRCRev
--------
	
	object = new ursObject("PRCRev", PRCRev_Constructor, PRCRev_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", PRCRev_Tick, PRCRev_Out, NULL);
	object->AddIn("In", "Generic", PRCRev_In);
	object->AddIn("T60", "Time", PRCRev_SetT60);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

ReedTbl
---------
	
	object = new ursObject("ReedTbl", ReedTable_Constructor, ReedTable_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", ReedTable_Tick, ReedTable_Out, NULL);
	object->AddIn("In", "Generic", ReedTable_In);
	object->AddIn("Offset", "Generic", ReedTable_SetOffset);
	object->AddIn("Slope", "Generic", ReedTable_SetSlope);
	object->SetCouple(0,0);
	urmanipulatorobjectlist.Append(object);

Saxofony
----------

	object = new ursObject("Saxofony", Saxofony_Constructor, Saxofony_Destructor,3,1);
	object->AddOut("WaveForm", "TimeSeries", Saxofony_Tick, Saxofony_Out, NULL);
	object->AddIn("In", "Generic", Saxofony_In);
	object->AddIn("Freq", "Frequency", Saxofony_SetFrequency);
	object->AddIn("Pos", "Position", Saxofony_SetBlowPosition);
	urmanipulatorobjectlist.Append(object);
	
Sitar
-------

	object = new ursObject("Sitar", Sitar_Constructor, Sitar_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Sitar_Tick, Sitar_Out, NULL);
	object->AddIn("In", "Generic", Sitar_In);
	object->AddIn("Freq", "Frequency", Sitar_SetFrequency);
	urmanipulatorobjectlist.Append(object);
	
StifKarp
----------
	
	object = new ursObject("StifKarp", StifKarp_Constructor, StifKarp_Destructor,5,1);
	object->AddOut("WaveForm", "TimeSeries", StifKarp_Tick, StifKarp_Out, NULL);
	object->AddIn("In", "Generic", StifKarp_In);
	object->AddIn("Freq", "Frequency", StifKarp_SetFrequency);
	object->AddIn("Stretch", "Generic", StifKarp_SetStretch);
	object->AddIn("Pos", "Position", StifKarp_SetPickupPosition);
	object->AddIn("Loop", "Gain", StifKarp_SetBaseLoopGain);
	urmanipulatorobjectlist.Append(object);
		
#ifdef INCLUDE_COMPHEAVY_STKS
	object = new ursObject("Whistle", Whistle_Constructor, Whistle_Destructor,2,1);
	object->AddOut("WaveForm", "TimeSeries", Whistle_Tick, Whistle_Out, NULL);
	object->AddIn("In", "Generic", Whistle_In);
	object->AddIn("Freq", "Frequency", Whistle_SetFrequency);
	urmanipulatorobjectlist.Append(object);
#endif
	
